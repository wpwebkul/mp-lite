<?php
/**
 * Silence is golden.
 *
 * Path: /woocommerce3.0-plugins/wp-woocommerce-marketplace
 *
 * @package Multi Vendor Marketplace
 */
