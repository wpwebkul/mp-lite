<?php
/**
 * Silence is golden.
 *
 * @package Multi-Vendor Marketplace for WooCommerce Lite
 */
