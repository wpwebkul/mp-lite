<?php
/**
 * Silence is golden.
 *
 * @package WK_Caching
 */
