<?php
/**
 * Seller product at front.
 *
 * @package Multi Vendor Marketplace
 * @version 5.0.0
 */

namespace WkMarketplace\Templates\Front\Seller\Profile;

defined( 'ABSPATH' ) || exit; // Exit if access directly.

if ( ! class_exists( 'WKMP_Profile_Edit' ) ) {
	/**
	 * Seller Profile Edit.
	 *
	 * Class WKMP_Profile_Edit
	 *
	 * @package WkMarketplace\Templates\Front\Seller\Profile
	 */
	class WKMP_Profile_Edit {
		/**
		 * Seller id.
		 *
		 * @var int $seller_id Seller id.
		 */
		protected $seller_id;

		/**
		 * Instance variable
		 *
		 * @var $instance
		 */
		protected static $instance = null;

		/**
		 * Errors.
		 *
		 * @var array $errors Errors.
		 */
		private $errors = array();

		/**
		 * Constructor of the class.
		 *
		 * WKMP_Profile_Edit constructor.
		 *
		 * @param int $seller_id Seller id.
		 */
		public function __construct( $seller_id = 0 ) {
			$this->seller_id = $seller_id;
		}

		/**
		 * Ensures only one instance of this class is loaded or can be loaded.
		 *
		 * @return object
		 */
		public static function get_instance() {
			if ( ! static::$instance ) {
				static::$instance = new self();
			}
			return static::$instance;
		}

		/**
		 * Seller profile form.
		 *
		 * @param int $seller_id Seller id.
		 *
		 * @return void
		 */
		public function wkmp_seller_profile_form( $seller_id ) {
			$this->seller_id = empty( $this->seller_id ) ? $seller_id : $this->seller_id;
			if ( isset( $_SERVER['REQUEST_METHOD'] ) && 'POST' === $_SERVER['REQUEST_METHOD'] ) {
				$posted_data = isset( $_POST ) ? wc_clean( $_POST ) : array(); //phpcs:ignore WordPress.Security.NonceVerification.Missing

				if ( empty( $posted_data['wkmp-user-nonce'] ) || ! wp_verify_nonce( wp_unslash( $posted_data['wkmp-user-nonce'] ), 'wkmp-user-nonce-action' ) ) {
					$this->errors['nonce_error'] = esc_html__( 'Nonce not validated', 'wk-marketplace' );
				} else {
					do_action( 'wkmp_validate_update_seller_profile', $posted_data, $this->seller_id );

					$posted_data = isset( $_POST ) ? wc_clean( $_POST ) : array(); //phpcs:ignore WordPress.Security.NonceVerification.Missing
					$errors      = empty( $posted_data['wkmp_errors'] ) ? array() : $posted_data['wkmp_errors'];

					if ( empty( $errors ) ) {
						wc_print_notice( esc_html__( 'Profile has been updated.', 'wk-marketplace' ), 'success' );
					} else {
						$this->errors = $errors;
					}
				}
			}

			$posted_data = isset( $_POST ) ? wc_clean( $_POST ) : array(); //phpcs:ignore WordPress.Security.NonceVerification.Missing

			$edit_form_obj = WKMP_Seller_Profile_Form::get_instance();
			$edit_form_obj->wkmp_seller_profile_edit_form( $this->seller_id, $this->errors, $posted_data );
		}
	}
}
