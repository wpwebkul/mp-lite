<?php
/**
 * Invoice footer.
 *
 * @package Multi Vendor Marketplace
 * @version 5.0.0
 */

defined( 'ABSPATH' ) || exit; // Exit if access directly.
?>
		</div>
	</body>
</html>
